$('.game-object[data-toggle="tooltip"]').tooltip({
  html: true,
});
